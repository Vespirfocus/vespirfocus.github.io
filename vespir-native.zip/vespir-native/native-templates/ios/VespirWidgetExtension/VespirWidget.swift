import WidgetKit
import SwiftUI

// MARK: - Veri

struct VespirData {
    var name = "Vespır"
    var en = false
    var streak = 0
    var doneToday = false
    var minutes = 0
    var goal = 120
    var timerEnd: Date? = nil
    var timerBreak = false
    var bg0 = Color(hex: "#050e16"), bg1 = Color(hex: "#0b2b3d"), bg2 = Color(hex: "#0e3a2c")
    var ink = Color(hex: "#f2f9ff"), ink2 = Color(hex: "#b9cfdd")
    var accent = Color(hex: "#ff7a80"), accent2 = Color(hex: "#6fd39a"), accent3 = Color(hex: "#ffd166")
    var fur = Color(hex: "#a59482"), belly = Color(hex: "#f3ebe0"), eyes = Color(hex: "#9cc45c"), patch = Color(hex: "#6f6153")

    static func dayKey(_ offset: Int, from date: Date = Date()) -> String {
        let d = Calendar.current.date(byAdding: .day, value: offset, to: date) ?? date
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: d)
    }

    static func load(at date: Date = Date()) -> VespirData {
        var s = VespirData()
        guard
            let raw = UserDefaults(suiteName: "group.app.vespir.focus")?.string(forKey: "snapshot"),
            let data = raw.data(using: .utf8),
            let o = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        else { return s }

        s.name = o["name"] as? String ?? "Vespır"
        s.en = (o["lang"] as? String) == "en"
        let last = o["streakLast"] as? String ?? ""
        let count = o["streakCount"] as? Int ?? 0
        s.doneToday = last == dayKey(0, from: date)
        s.streak = (s.doneToday || last == dayKey(-1, from: date)) ? count : 0
        let sameDay = (o["day"] as? String) == dayKey(0, from: date)
        s.minutes = sameDay ? (o["minutes"] as? Int ?? 0) : 0
        s.goal = max(15, o["goal"] as? Int ?? 120)
        if let t = o["timer"] as? [String: Any], let end = t["endAt"] as? Double {
            let endDate = Date(timeIntervalSince1970: end / 1000)
            if endDate > date {
                s.timerEnd = endDate
                s.timerBreak = (t["phase"] as? String) == "break"
            }
        }
        if let c = o["colors"] as? [String: String] {
            s.bg0 = Color(hex: c["bg0"], s.bg0); s.bg1 = Color(hex: c["bg1"], s.bg1); s.bg2 = Color(hex: c["bg2"], s.bg2)
            s.ink = Color(hex: c["ink"], s.ink); s.ink2 = Color(hex: c["ink2"], s.ink2)
            s.accent = Color(hex: c["accent"], s.accent); s.accent2 = Color(hex: c["accent2"], s.accent2)
            s.accent3 = Color(hex: c["accent3"], s.accent3)
        }
        if let k = o["cat"] as? [String: String] {
            s.fur = Color(hex: k["fur"], s.fur); s.belly = Color(hex: k["belly"], s.belly)
            s.eyes = Color(hex: k["eyes"], s.eyes); s.patch = Color(hex: k["patch"], s.patch)
        }
        return s
    }

    var headline: String {
        if timerEnd != nil { return timerBreak ? (en ? "Break time" : "Mola zamanı") : (en ? "You're in the zone!" : "Odaktasın!") }
        if minutes >= goal { return en ? "Goal crushed!" : "Hedef tamam!" }
        if doneToday { return en ? "Streak saved today" : "Bugünün serisi tamam" }
        if streak > 0 { return en ? "Keep your streak!" : "Serini koru!" }
        return en ? "Let's start a streak" : "Hadi seriye başla"
    }
    var streakLabel: String { en ? "day streak" : "günlük seri" }
    var goalText: String { en ? "\(minutes) / \(goal) min" : "\(minutes) / \(goal) dk" }
    var progress: Double { min(1, Double(minutes) / Double(goal)) }
    var flameLit: Bool { doneToday || timerEnd != nil }
}

extension Color {
    init(hex: String?, _ fallback: Color = .gray) {
        if let h = hex, h.hasPrefix("#"), h.count == 7, let v = UInt32(h.dropFirst(), radix: 16) {
            self.init(red: Double((v >> 16) & 255) / 255, green: Double((v >> 8) & 255) / 255, blue: Double(v & 255) / 255)
        } else {
            self = fallback
        }
    }
}

// MARK: - Zaman çizelgesi

struct VespirEntry: TimelineEntry {
    let date: Date
    let data: VespirData
}

struct VespirProvider: TimelineProvider {
    func placeholder(in context: Context) -> VespirEntry { VespirEntry(date: Date(), data: VespirData()) }

    func getSnapshot(in context: Context, completion: @escaping (VespirEntry) -> Void) {
        completion(VespirEntry(date: Date(), data: VespirData.load()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<VespirEntry>) -> Void) {
        let now = Date()
        var entries = [VespirEntry(date: now, data: VespirData.load(at: now))]
        let data = entries[0].data
        // Sayaç bitince ve gece yarısı (seri/hedef sıfırlanır) görünümü tazele.
        if let end = data.timerEnd {
            entries.append(VespirEntry(date: end.addingTimeInterval(1), data: VespirData.load(at: end.addingTimeInterval(1))))
        }
        let calendar = Calendar.current
        if let nextMidnight = calendar.date(byAdding: .day, value: 1, to: calendar.startOfDay(for: now)) {
            let midnight = nextMidnight.addingTimeInterval(5)
            entries.append(VespirEntry(date: midnight, data: VespirData.load(at: midnight)))
        }
        entries.sort { $0.date < $1.date }
        completion(Timeline(entries: entries, policy: .after(now.addingTimeInterval(30 * 60))))
    }
}

// MARK: - Çizimler

struct FlameShape: Shape {
    func path(in r: CGRect) -> Path {
        func p(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: r.minX + r.width * x / 100, y: r.minY + r.height * y / 100) }
        var path = Path()
        path.move(to: p(50, 4))
        path.addCurve(to: p(84, 64), control1: p(58, 24), control2: p(86, 36))
        path.addCurve(to: p(50, 97), control1: p(83, 86), control2: p(66, 97))
        path.addCurve(to: p(16, 64), control1: p(34, 97), control2: p(17, 86))
        path.addCurve(to: p(31, 34), control1: p(15, 50), control2: p(24, 42))
        path.addCurve(to: p(41, 50), control1: p(32, 46), control2: p(38, 50))
        path.addCurve(to: p(50, 4), control1: p(38, 32), control2: p(42, 16))
        path.closeSubpath()
        return path
    }
}

struct FlameInner: Shape {
    func path(in r: CGRect) -> Path {
        func p(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: r.minX + r.width * x / 100, y: r.minY + r.height * y / 100) }
        var path = Path()
        path.move(to: p(50, 52))
        path.addCurve(to: p(66, 80), control1: p(58, 62), control2: p(68, 68))
        path.addCurve(to: p(50, 94), control1: p(65, 90), control2: p(57, 94))
        path.addCurve(to: p(34, 80), control1: p(43, 94), control2: p(35, 90))
        path.addCurve(to: p(50, 52), control1: p(33, 70), control2: p(44, 64))
        path.closeSubpath()
        return path
    }
}

struct FlameView: View {
    let d: VespirData
    var body: some View {
        ZStack {
            FlameShape().fill(LinearGradient(
                colors: d.flameLit ? [d.accent3, d.accent] : [d.ink.opacity(0.45), d.ink.opacity(0.25)],
                startPoint: .top, endPoint: .bottom))
            FlameInner().fill(Color.white.opacity(d.flameLit ? 0.68 : 0.28))
        }
    }
}

struct Tri: Shape {
    let a: CGPoint, b: CGPoint, c: CGPoint
    func path(in r: CGRect) -> Path {
        func m(_ q: CGPoint) -> CGPoint { CGPoint(x: r.minX + r.width * q.x / 100, y: r.minY + r.height * q.y / 100) }
        var p = Path(); p.move(to: m(a)); p.addLine(to: m(b)); p.addLine(to: m(c)); p.closeSubpath(); return p
    }
}

struct CatFace: View {
    let d: VespirData
    var body: some View {
        GeometryReader { g in
            let w = g.size.width, h = g.size.height
            ZStack {
                Tri(a: CGPoint(x: 14, y: 52), b: CGPoint(x: 18, y: 8), c: CGPoint(x: 46, y: 30)).fill(d.fur)
                Tri(a: CGPoint(x: 86, y: 52), b: CGPoint(x: 82, y: 8), c: CGPoint(x: 54, y: 30)).fill(d.fur)
                Tri(a: CGPoint(x: 21, y: 44), b: CGPoint(x: 23, y: 20), c: CGPoint(x: 38, y: 33)).fill(Color(red: 1, green: 0.62, blue: 0.71).opacity(0.75))
                Tri(a: CGPoint(x: 79, y: 44), b: CGPoint(x: 77, y: 20), c: CGPoint(x: 62, y: 33)).fill(Color(red: 1, green: 0.62, blue: 0.71).opacity(0.75))
                Ellipse().fill(d.fur).frame(width: w * 0.84, height: h * 0.68).position(x: w * 0.5, y: h * 0.58)
                Ellipse().fill(d.patch).frame(width: w * 0.20, height: h * 0.20).position(x: w * 0.5, y: h * 0.35)
                Ellipse().fill(d.belly).frame(width: w * 0.40, height: h * 0.30).position(x: w * 0.5, y: h * 0.71)
                ForEach([33.0, 67.0], id: \.self) { cx in
                    ZStack {
                        Ellipse().fill(d.eyes).frame(width: w * 0.18, height: h * 0.20)
                        Capsule().fill(Color(red: 0.11, green: 0.08, blue: 0.09)).frame(width: w * 0.065, height: h * 0.16)
                        Circle().fill(Color.white).frame(width: w * 0.045).offset(x: w * 0.035, y: -h * 0.05)
                    }
                    .position(x: w * cx / 100, y: h * 0.56)
                }
                Tri(a: CGPoint(x: 45, y: 69), b: CGPoint(x: 55, y: 69), c: CGPoint(x: 50, y: 75)).fill(Color(red: 1, green: 0.56, blue: 0.66))
            }
        }
        .aspectRatio(1, contentMode: .fit)
    }
}

struct GoalBar: View {
    let d: VespirData
    var body: some View {
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule().fill(d.ink.opacity(0.18))
                if d.progress > 0 {
                    Capsule()
                        .fill(LinearGradient(colors: [d.accent, d.accent2], startPoint: .leading, endPoint: .trailing))
                        .frame(width: max(g.size.height, g.size.width * d.progress))
                }
            }
        }
        .frame(height: 9)
    }
}

struct TimerText: View {
    let d: VespirData
    var size: CGFloat
    var body: some View {
        if let end = d.timerEnd {
            let now = Date()
            Group {
                if end > now {
                    Text(timerInterval: now...end, countsDown: true)
                } else {
                    Text("0:00")
                }
            }
            .font(.system(size: size, weight: .bold, design: .rounded))
            .monospacedDigit()
            .foregroundStyle(d.accent)
        }
    }
}

struct VespirBackground: View {
    let d: VespirData
    var body: some View {
        ZStack {
            LinearGradient(colors: [d.bg1.mix(d.accent, 0.24), d.bg0.mix(d.accent2, 0.16), d.bg0],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            RadialGradient(colors: [d.accent.opacity(0.42), .clear], center: .topTrailing, startRadius: 0, endRadius: 190)
        }
    }
}

extension Color {
    /// iOS 16 uyumlu basit karışım.
    func mix(_ other: Color, _ t: Double) -> Color {
        let a = UIColor(self), b = UIColor(other)
        var ar: CGFloat = 0, ag: CGFloat = 0, ab: CGFloat = 0, aa: CGFloat = 0
        var br: CGFloat = 0, bg: CGFloat = 0, bb: CGFloat = 0, ba: CGFloat = 0
        _ = a.getRed(&ar, green: &ag, blue: &ab, alpha: &aa)
        _ = b.getRed(&br, green: &bg, blue: &bb, alpha: &ba)
        return Color(red: ar + (br - ar) * t, green: ag + (bg - ag) * t, blue: ab + (bb - ab) * t)
    }
}

// MARK: - Widget görünümleri

struct SmallView: View {
    let d: VespirData
    var body: some View {
        ZStack(alignment: .topTrailing) {
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 4) {
                    FlameView(d: d).frame(width: 30, height: 30)
                    Text("\(d.streak)")
                        .font(.system(size: 32, weight: .heavy, design: .rounded))
                        .foregroundStyle(d.doneToday ? d.accent3 : d.ink)
                        .minimumScaleFactor(0.6)
                }
                Text(d.streakLabel).font(.system(size: 11)).foregroundStyle(d.ink2)
                TimerText(d: d, size: 17)
                Spacer(minLength: 0)
                Text(d.headline)
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .foregroundStyle(d.ink)
                    .lineLimit(2)
                    .padding(.bottom, 5)
                GoalBar(d: d)
                Text(d.goalText).font(.system(size: 10)).foregroundStyle(d.ink2).padding(.top, 3)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            CatFace(d: d).frame(width: 48, height: 48)
        }
    }
}

struct MediumView: View {
    let d: VespirData
    var body: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 4) {
                    FlameView(d: d).frame(width: 40, height: 40)
                    Text("\(d.streak)")
                        .font(.system(size: 42, weight: .heavy, design: .rounded))
                        .foregroundStyle(d.doneToday ? d.accent3 : d.ink)
                }
                Text(d.streakLabel).font(.system(size: 12)).foregroundStyle(d.ink2)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(d.headline)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .foregroundStyle(d.ink)
                    .lineLimit(2)
                TimerText(d: d, size: 22)
                Spacer(minLength: 2)
                GoalBar(d: d)
                Text(d.goalText).font(.system(size: 11)).foregroundStyle(d.ink2)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            CatFace(d: d).frame(width: 70, height: 70)
        }
    }
}

struct LockCircular: View {
    let d: VespirData
    var body: some View {
        Gauge(value: d.progress) {
            Image(systemName: "flame.fill")
        } currentValueLabel: {
            Text("\(d.streak)")
        }
        .gaugeStyle(.accessoryCircular)
    }
}

struct VespirWidgetView: View {
    @Environment(\.widgetFamily) var family
    let entry: VespirEntry
    var legacy = false   // iOS 16: containerBackground yok, kenar boşluğu ve arka planı biz veririz

    var isAccessory: Bool { family == .accessoryCircular || family == .accessoryRectangular }

    @ViewBuilder
    var body: some View {
        if legacy && !isAccessory {
            content.padding(14).background(VespirBackground(d: entry.data))
        } else {
            content
        }
    }

    @ViewBuilder
    var content: some View {
        switch family {
        case .accessoryCircular:
            LockCircular(d: entry.data)
        case .accessoryRectangular:
            VStack(alignment: .leading) {
                Text("\(entry.data.streak) \(entry.data.streakLabel)").font(.headline)
                Text(entry.data.goalText).font(.caption)
                Gauge(value: entry.data.progress) { EmptyView() }.gaugeStyle(.accessoryLinearCapacity)
            }
        case .systemMedium:
            MediumView(d: entry.data)
        default:
            SmallView(d: entry.data)
        }
    }
}

struct VespirWidget: Widget {
    let kind = "VespirWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: VespirProvider()) { entry in
            if #available(iOS 17.0, *) {
                VespirWidgetView(entry: entry)
                    .containerBackground(for: .widget) { VespirBackground(d: entry.data) }
            } else {
                VespirWidgetView(entry: entry, legacy: true)
            }
        }
        .configurationDisplayName("Vespır")
        .description("Seri, günlük hedef ve odak sayacın.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryCircular, .accessoryRectangular])
    }
}

@main
struct VespirWidgetBundle: WidgetBundle {
    var body: some Widget { VespirWidget() }
}
