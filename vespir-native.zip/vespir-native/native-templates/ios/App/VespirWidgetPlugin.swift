import Foundation
import Capacitor
import WidgetKit

/// index.html köprüsü: Capacitor.Plugins.VespirWidget.update({ json })
/// Özeti App Group deposuna yazar ve widget zaman çizelgesini yeniletir.
@objc(VespirWidgetPlugin)
public class VespirWidgetPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "VespirWidgetPlugin"
    public let jsName = "VespirWidget"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "update", returnType: CAPPluginReturnPromise)
    ]

    static let group = "group.app.vespir.focus"

    @objc func update(_ call: CAPPluginCall) {
        guard let json = call.getString("json") else {
            call.reject("json yok")
            return
        }
        UserDefaults(suiteName: VespirWidgetPlugin.group)?.set(json, forKey: "snapshot")
        if #available(iOS 14.0, *) {
            WidgetCenter.shared.reloadAllTimelines()
        }
        call.resolve()
    }
}
