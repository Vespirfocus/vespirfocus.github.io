import UIKit
import Capacitor

/// Yerel eklentiyi Capacitor'a tanıtır. Main.storyboard'daki görünüm denetleyicisinin
/// Custom Class alanını "MyViewController" (Module: App) yap.
class MyViewController: CAPBridgeViewController {
    override func capacitorDidLoad() {
        bridge?.registerPluginInstance(VespirWidgetPlugin())
    }
}
