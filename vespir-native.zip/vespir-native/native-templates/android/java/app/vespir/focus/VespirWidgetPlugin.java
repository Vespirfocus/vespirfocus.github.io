package app.vespir.focus;

import android.content.Context;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** index.html içindeki köprü bu eklentiyi çağırır: Capacitor.Plugins.VespirWidget.update({ json }) */
@CapacitorPlugin(name = "VespirWidget")
public class VespirWidgetPlugin extends Plugin {
    @PluginMethod
    public void update(PluginCall call) {
        String json = call.getString("json");
        if (json == null) { call.reject("json yok"); return; }
        Context ctx = getContext();
        VespirSnapshot.save(ctx, json);
        VespirWidgetProvider.refreshAll(ctx);
        call.resolve();
    }
}
