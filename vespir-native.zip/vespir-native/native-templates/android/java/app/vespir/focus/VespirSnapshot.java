package app.vespir.focus;

import android.content.Context;
import android.graphics.Color;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/** Web uygulamasından gelen özet; widget yalnızca bunu okur. */
public final class VespirSnapshot {
    static final String PREFS = "vespir_widget";
    static final String KEY = "snapshot";

    public String name = "Vespır";
    public boolean en;
    public int streak;
    public boolean doneToday;
    public int minutes;
    public int sessions;
    public int goal = 120;
    public String timerPhase;      // "focus" | "break" | null
    public long timerEnd;          // epoch ms, 0 = yok
    public int bg0 = 0xFF050E16, bg1 = 0xFF0B2B3D, bg2 = 0xFF0E3A2C;
    public int ink = 0xFFF2F9FF, ink2 = 0xFFB9CFDD;
    public int accent = 0xFFFF7A80, accent2 = 0xFF6FD39A, accent3 = 0xFFFFD166, onAccent = 0xFF1A090B;
    public int fur = 0xFFA59482, belly = 0xFFF3EBE0, eyes = 0xFF9CC45C, patch = 0xFF6F6153;

    static String dayKey(int offset) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, offset);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    public static void save(Context ctx, String json) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply();
    }

    public static VespirSnapshot load(Context ctx) {
        String json = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null);
        VespirSnapshot s = new VespirSnapshot();
        if (json == null) return s;
        try {
            JSONObject o = new JSONObject(json);
            s.name = o.optString("name", "Vespır");
            s.en = "en".equals(o.optString("lang"));
            String last = o.optString("streakLast", "");
            int count = o.optInt("streakCount", 0);
            s.doneToday = last.equals(dayKey(0));
            s.streak = (s.doneToday || last.equals(dayKey(-1))) ? count : 0;
            boolean sameDay = o.optString("day", "").equals(dayKey(0));
            s.minutes = sameDay ? o.optInt("minutes", 0) : 0;
            s.sessions = sameDay ? o.optInt("sessions", 0) : 0;
            s.goal = Math.max(15, o.optInt("goal", 120));
            JSONObject t = o.optJSONObject("timer");
            if (t != null && t.optLong("endAt", 0) > System.currentTimeMillis()) {
                s.timerEnd = t.optLong("endAt");
                s.timerPhase = t.optString("phase", "focus");
            }
            JSONObject c = o.optJSONObject("colors");
            if (c != null) {
                s.bg0 = col(c, "bg0", s.bg0); s.bg1 = col(c, "bg1", s.bg1); s.bg2 = col(c, "bg2", s.bg2);
                s.ink = col(c, "ink", s.ink); s.ink2 = col(c, "ink2", s.ink2);
                s.accent = col(c, "accent", s.accent); s.accent2 = col(c, "accent2", s.accent2);
                s.accent3 = col(c, "accent3", s.accent3); s.onAccent = col(c, "onAccent", s.onAccent);
            }
            JSONObject k = o.optJSONObject("cat");
            if (k != null) {
                s.fur = col(k, "fur", s.fur); s.belly = col(k, "belly", s.belly);
                s.eyes = col(k, "eyes", s.eyes); s.patch = col(k, "patch", s.patch);
            }
        } catch (Exception ignored) { }
        return s;
    }

    private static int col(JSONObject o, String key, int fallback) {
        try { return Color.parseColor(o.optString(key)); } catch (Exception e) { return fallback; }
    }

    public String headline() {
        if (timerEnd > 0) {
            if ("break".equals(timerPhase)) return en ? "Break time" : "Mola zamanı";
            return en ? "You're in the zone!" : "Odaktasın!";
        }
        if (minutes >= goal) return en ? "Goal crushed!" : "Hedef tamam!";
        if (doneToday) return en ? "Streak saved today" : "Bugünün serisi tamam";
        if (streak > 0) return en ? "Keep your streak!" : "Serini koru!";
        return en ? "Let's start a streak" : "Hadi seriye başla";
    }

    public String goalText() {
        return en ? minutes + " / " + goal + " min" : minutes + " / " + goal + " dk";
    }

    public String streakLabel() {
        return en ? "day streak" : "günlük seri";
    }
}
