package app.vespir.focus;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;

import java.util.Calendar;

/** Duolingo tarzı ana ekran widget'ı: seri alevi, günlük hedef çubuğu, kedi ve canlı sayaç. */
public class VespirWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) render(ctx, mgr, id);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context ctx, AppWidgetManager mgr, int id, Bundle opts) {
        render(ctx, mgr, id);
    }

    public static void refreshAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, VespirWidgetProvider.class));
        for (int id : ids) render(ctx, mgr, id);
    }

    static void render(Context ctx, AppWidgetManager mgr, int id) {
        VespirSnapshot s = VespirSnapshot.load(ctx);
        Bundle o = mgr.getAppWidgetOptions(id);
        int wDp = Math.max(110, o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 110));
        int hDp = Math.min(400, Math.max(110, o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110)));
        boolean wide = wDp >= 250;

        RemoteViews rv = new RemoteViews(ctx.getPackageName(), wide ? R.layout.vespir_widget_wide : R.layout.vespir_widget_small);

        // Bellek sınırı için bitmap'ler dp*2 ölçüsünde, en çok 720 px genişlikte.
        float k = Math.min(2f, 720f / wDp);
        int wPx = Math.round(wDp * k), hPx = Math.round(hDp * k);
        rv.setImageViewBitmap(R.id.bg, background(wPx, hPx, s));
        rv.setImageViewBitmap(R.id.flame, flame(160, s));
        rv.setImageViewBitmap(R.id.cat, cat(220, s));
        rv.setImageViewBitmap(R.id.bar, bar(Math.round((wide ? wPx * 0.55f : wPx * 0.84f)), 20, s));

        rv.setTextViewText(R.id.streak, String.valueOf(s.streak));
        rv.setTextColor(R.id.streak, s.doneToday ? s.accent3 : s.ink);
        rv.setTextViewText(R.id.streakLabel, s.streakLabel());
        rv.setTextColor(R.id.streakLabel, s.ink2);
        rv.setTextViewText(R.id.headline, s.headline());
        rv.setTextColor(R.id.headline, s.ink);
        rv.setTextViewText(R.id.goal, s.goalText());
        rv.setTextColor(R.id.goal, s.ink2);

        // Geri sayım göstergesi Android 7+ (API 24) ister; daha eskide gizli kalır.
        if (s.timerEnd > 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            long base = SystemClock.elapsedRealtime() + (s.timerEnd - System.currentTimeMillis());
            rv.setChronometerCountDown(R.id.timer, true);
            rv.setChronometer(R.id.timer, base, null, true);
            rv.setTextColor(R.id.timer, s.accent);
            rv.setViewVisibility(R.id.timer, View.VISIBLE);
        } else {
            rv.setViewVisibility(R.id.timer, View.GONE);
        }
        // Sayaç bitince ve gece yarısı (seri/hedef sıfırlanır) widget bir kez tazelenir.
        if (s.timerEnd > 0) scheduleRefresh(ctx, s.timerEnd + 1000, 1);
        scheduleRefresh(ctx, nextMidnight(), 2);

        Intent launch = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
        if (launch != null) {
            PendingIntent pi = PendingIntent.getActivity(ctx, 0, launch, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            rv.setOnClickPendingIntent(R.id.root, pi);
        }
        mgr.updateAppWidget(id, rv);
    }

    static long nextMidnight() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, 1);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 5);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    /** Widget'ı verilen anda bir kez tazeler (kesin alarm izni gerekmez, sistem biraz geciktirebilir). */
    static void scheduleRefresh(Context ctx, long atMs, int code) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(ctx, VespirWidgetProvider.class).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS,
                AppWidgetManager.getInstance(ctx).getAppWidgetIds(new ComponentName(ctx, VespirWidgetProvider.class)));
        PendingIntent pi = PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        am.set(AlarmManager.RTC, atMs, pi);
    }

    // ---------- çizimler ----------

    static Bitmap background(int w, int h, VespirSnapshot s) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        float r = Math.min(w, h) * 0.2f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h, new int[]{blend(s.bg1, s.accent, .24f), blend(s.bg0, s.accent2, .16f), s.bg0}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
        Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        glow.setShader(new RadialGradient(w * .9f, 0, Math.max(w, h) * .7f, withAlpha(s.accent, 110), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, 0, w, h), r, r, glow);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2f);
        stroke.setColor(withAlpha(0xFFFFFFFF, 40));
        c.drawRoundRect(new RectF(1, 1, w - 1, h - 1), r, r, stroke);
        return b;
    }

    static Bitmap bar(int w, int h, VespirSnapshot s) {
        Bitmap b = Bitmap.createBitmap(Math.max(40, w), h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(withAlpha(s.ink, 45));
        c.drawRoundRect(new RectF(0, 0, b.getWidth(), h), h / 2f, h / 2f, p);
        float frac = Math.min(1f, s.minutes / (float) s.goal);
        if (frac > 0) {
            float fw = Math.max(h, b.getWidth() * frac);
            p.setShader(new LinearGradient(0, 0, fw, 0, s.accent, s.accent2, Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(0, 0, fw, h), h / 2f, h / 2f, p);
            Paint shine = new Paint(Paint.ANTI_ALIAS_FLAG);
            shine.setColor(withAlpha(0xFFFFFFFF, 70));
            c.drawRoundRect(new RectF(h * .4f, h * .18f, Math.max(h * .6f, fw - h * .4f), h * .42f), h / 4f, h / 4f, shine);
        }
        return b;
    }

    static Bitmap flame(int n, VespirSnapshot s) {
        Bitmap b = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        boolean lit = s.doneToday || s.timerEnd > 0;
        int top = lit ? s.accent3 : withAlpha(s.ink, 120);
        int bottom = lit ? s.accent : withAlpha(s.ink, 70);
        Path f = new Path();
        float u = n / 100f;
        f.moveTo(50 * u, 4 * u);
        f.cubicTo(58 * u, 24 * u, 86 * u, 36 * u, 84 * u, 64 * u);
        f.cubicTo(83 * u, 86 * u, 66 * u, 97 * u, 50 * u, 97 * u);
        f.cubicTo(34 * u, 97 * u, 17 * u, 86 * u, 16 * u, 64 * u);
        f.cubicTo(15 * u, 50 * u, 24 * u, 42 * u, 31 * u, 34 * u);
        f.cubicTo(32 * u, 46 * u, 38 * u, 50 * u, 41 * u, 50 * u);
        f.cubicTo(38 * u, 32 * u, 42 * u, 16 * u, 50 * u, 4 * u);
        f.close();
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, n, top, bottom, Shader.TileMode.CLAMP));
        c.drawPath(f, p);
        Path in = new Path();
        in.moveTo(50 * u, 52 * u);
        in.cubicTo(58 * u, 62 * u, 68 * u, 68 * u, 66 * u, 80 * u);
        in.cubicTo(65 * u, 90 * u, 57 * u, 94 * u, 50 * u, 94 * u);
        in.cubicTo(43 * u, 94 * u, 35 * u, 90 * u, 34 * u, 80 * u);
        in.cubicTo(33 * u, 70 * u, 44 * u, 64 * u, 50 * u, 52 * u);
        in.close();
        Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
        q.setColor(withAlpha(0xFFFFFFFF, lit ? 175 : 70));
        c.drawPath(in, q);
        return b;
    }

    static Bitmap cat(int n, VespirSnapshot s) {
        Bitmap b = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        float u = n / 100f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        // kulaklar
        p.setColor(s.fur);
        Path ear = new Path();
        ear.moveTo(14 * u, 52 * u); ear.lineTo(18 * u, 8 * u); ear.lineTo(46 * u, 30 * u); ear.close();
        c.drawPath(ear, p);
        Path ear2 = new Path();
        ear2.moveTo(86 * u, 52 * u); ear2.lineTo(82 * u, 8 * u); ear2.lineTo(54 * u, 30 * u); ear2.close();
        c.drawPath(ear2, p);
        p.setColor(blend(s.belly, 0xFFFF9EB5, .55f));
        Path in1 = new Path();
        in1.moveTo(21 * u, 44 * u); in1.lineTo(23 * u, 20 * u); in1.lineTo(38 * u, 33 * u); in1.close();
        c.drawPath(in1, p);
        Path in2 = new Path();
        in2.moveTo(79 * u, 44 * u); in2.lineTo(77 * u, 20 * u); in2.lineTo(62 * u, 33 * u); in2.close();
        c.drawPath(in2, p);
        // kafa
        p.setColor(s.fur);
        c.drawOval(new RectF(8 * u, 24 * u, 92 * u, 92 * u), p);
        // alın lekesi
        p.setColor(s.patch);
        c.drawOval(new RectF(40 * u, 25 * u, 60 * u, 45 * u), p);
        // yanak/burun bölgesi
        p.setColor(s.belly);
        c.drawOval(new RectF(30 * u, 56 * u, 70 * u, 86 * u), p);
        // gözler
        for (int i = 0; i < 2; i++) {
            float cx = (i == 0 ? 33 : 67) * u, cy = 56 * u;
            p.setColor(s.eyes);
            c.drawOval(new RectF(cx - 9 * u, cy - 10 * u, cx + 9 * u, cy + 10 * u), p);
            p.setColor(0xFF1B1416);
            c.drawOval(new RectF(cx - 3.2f * u, cy - 8 * u, cx + 3.2f * u, cy + 8 * u), p);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(cx + 3.5f * u, cy - 5 * u, 2.2f * u, p);
        }
        // burun + ağız
        p.setColor(0xFFFF8FA8);
        Path nose = new Path();
        nose.moveTo(45 * u, 69 * u); nose.lineTo(55 * u, 69 * u); nose.lineTo(50 * u, 75 * u); nose.close();
        c.drawPath(nose, p);
        Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(1.8f * u);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setColor(withAlpha(0xFF3A2A2E, 200));
        Path mouth = new Path();
        mouth.moveTo(50 * u, 75 * u); mouth.lineTo(50 * u, 79 * u);
        mouth.moveTo(41 * u, 80 * u); mouth.quadTo(46 * u, 84 * u, 50 * u, 79 * u);
        mouth.quadTo(54 * u, 84 * u, 59 * u, 80 * u);
        c.drawPath(mouth, line);
        return b;
    }

    // ---------- renk yardımcıları ----------
    static int withAlpha(int color, int a) { return (color & 0x00FFFFFF) | (a << 24); }

    static int blend(int a, int b, float t) {
        int ar = Color.red(a), ag = Color.green(a), ab = Color.blue(a);
        int br = Color.red(b), bg = Color.green(b), bb = Color.blue(b);
        return Color.rgb(Math.round(ar + (br - ar) * t), Math.round(ag + (bg - ag) * t), Math.round(ab + (bb - ab) * t));
    }
}
