# Vespır — gerçek ana ekran widget'ları (Android + iOS)

Neden ayrı bir paket? Tarayıcıdan "ana ekrana ekle" ile kurulan bir PWA, Android'de de iOS'ta da
ana ekrana **widget koyamaz**; widget'lar yalnızca yerel (native) uygulamalarda olur.
Bu yüzden uygulamanı **Capacitor** ile yerel bir kabuğa sarıyoruz (aynı `index.html` çalışır) ve
yanına iki küçük yerel widget ekliyoruz:

- **Android:** App Widget (2x2 ve 4x2, yeniden boyutlandırılabilir)
- **iOS:** WidgetKit (küçük, orta, kilit ekranı yuvarlak ve dikdörtgen)

Görünüm Duolingo tarzı: büyük **seri alevi + sayı**, gradyan **günlük hedef çubuğu**, Vespır'ın yüzü
(kendi renklerinle), **canlı geri sayım** ve motive edici başlık. Renkler seçili temadan (Noel vb.)
otomatik gelir.

> Ne kontrol edildi, ne edilmedi:
> - Yerel kaynaklar (Java, Swift, XML) elle gözden geçirildi; Android layout'undaki desteklenmeyen
>   `<View>` boşluğu `TextView` ile değiştirildi, Swift'te renk/gece yarısı/sayaç düzeltmeleri yapıldı.
> - **Gerçek Android Studio / Xcode derlemesi yapılmadı; hiçbir telefonda denenmedi.** İlk derlemede
>   küçük hatalar çıkabilir; hata mesajını yapıştır, düzeltelim.
> - Web tarafı (`www/index.html`, `www/sw.js`, `www/widget.html`) ayrı olarak Chrome'da test edildi;
>   bu, yerel kabuğun derlendiği anlamına gelmez.

## Paket içeriği
- `www/` → uygulamanın web dosyaları (`index.html`, `sw.js`, `widget.html`). Capacitor burayı paketler.
- `native-templates/android/` ve `native-templates/ios/` → **şablon** yerel kaynaklar.
  Bunlar doğrudan platform klasörü değildir; `npx cap add` gerçek `android/` ve `ios/` projelerini
  oluşturduktan sonra içlerinden ilgili dosyaları kopyalarsın. (Şablonları `android/`/`ios/` adıyla
  bırakmak `cap add`'ın "klasör zaten var" hatası vermesine yol açar.)
- `capacitor.config.json` → `appId: app.vespir.focus`, `webDir: www`.

## Ne değişti?
`www/index.html` (senin dosyan) şu eklerle güncellendi:
1. **Seri (streak)**: gün içinde en az bir odak seansı bitince o gün sayılır; dün sayıldıysa seri artar,
   bir gün atlanırsa 1'e döner. (`S.streak`, `bumpStreak()`)
2. **Widget köprüsü** (dosyanın sonunda): sadece yerel uygulamada çalışır, tarayıcıda hiçbir şey yapmaz.
   Seri, bugünkü dakika, hedef, sayaç ve tema renklerini widget'a gönderir.

`www/sw.js` ve `www/widget.html` de güncel hâlleriyle paketlendi.

## Gereksinimler (Capacitor 8)
- **Node.js 22+**
- **Android:** Android Studio Otter 2025.2.1+, Android SDK 36, Gradle 8.13.0
- **iOS:** Mac + Xcode 26.0+, iOS deployment target 15.0 (kilit ekranı widget'ları için 16.0)

## Kurulum (ortak)
```bash
npm install
npx cap add android      # gerçek android/ projesini oluşturur
npx cap add ios          # gerçek ios/ projesini oluşturur (sadece Mac'te)
npx cap sync
```
`appId` olarak `app.vespir.focus` kullanıldı. Değiştirirsen Java `package` satırlarını, `R` importunu
ve App Group adını da aynı şekilde değiştir.

## Android
1. `native-templates/android/java/app/vespir/focus/*.java` dosyalarını
   `android/app/src/main/java/app/vespir/focus/` içine kopyala.
2. `native-templates/android/res/` altındaki **layout, xml, values ve drawable** klasörlerini
   `android/app/src/main/res/` altındaki aynı klasörlere kopyala. (`drawable/vespir_widget_bg.xml`
   arka plan için gereklidir; atlama.)
3. `native-templates/android/AndroidManifest.receiver.xml` içindeki `<receiver>` bloğunu
   `android/app/src/main/AndroidManifest.xml`'de `<application>` içine yapıştır.
4. `native-templates/android/MainActivity.java.txt` içeriğiyle `MainActivity.java` dosyasını değiştir.
5. `npx cap open android` → çalıştır. Ana ekranda uzun bas → Widget'lar → **Vespır**.

## iOS (Mac + Xcode gerekir)
1. `npx cap open ios`. Hem **App** hem de widget hedefinin **iOS Deployment Target** değerini
   **16.0** yap (kilit ekranı widget'ları için).
2. **File → New → Target → Widget Extension**, adı `VespirWidgetExtension`;
   "Include Live Activity/Configuration" kutularını kapat. Otomatik oluşan Swift dosyalarını sil,
   yerine `native-templates/ios/VespirWidgetExtension/VespirWidget.swift` dosyasını ekle.
3. Hem **App** hem **VespirWidgetExtension** hedefinde:
   *Signing & Capabilities → + Capability → App Groups* → `group.app.vespir.focus` ekle
   (aynı ad ikisinde de olmalı).
4. `native-templates/ios/App/VespirWidgetPlugin.swift` ve `MyViewController.swift` dosyalarını
   **App** hedefine ekle.
5. `Main.storyboard` → görünüm denetleyicisi → Custom Class = `MyViewController` (Module: App).
6. Çalıştır, ana ekrana uzun bas → **+** → Vespır. Kilit ekranı widget'ları iOS 16+'da eklenebilir.

## Bilmen gerekenler
- Widget, uygulamayı en az bir kez açıp bir şey kaydedildiğinde (örn. seans bitince) güncellenir.
  Uygulama kapalıyken sistem widget'ı kendi aralığında tazeler; **sayaç** ise canlı akar
  (Android'de Chronometer, iOS'ta sistem sayacı). Güncelleme sıklığını işletim sistemi belirler;
  kesin an garantisi yoktur.
- Gece yarısından sonra widget, uygulamayı açmasan bile seri/hedefi sıfırlanmış göstermeye çalışır;
  iOS'ta zamanlama daha öngörülebilir, Android'de sistem geciktirebilir.
- Android 7'den eski telefonlarda canlı geri sayım gizlenir, diğer her şey çalışır.
- **İmza:** Mağazaya yüklemek için Apple Developer (yıllık ücretli) ve Google Play hesabı gerekir.
  Android'de kendi telefonuna APK ile kurmak için ücretli hesap gerekmez. iOS'ta App Groups ve
  Widget Extension gibi yetenekler uygun bir geliştirici hesabı/imza gerektirir; ücretsiz kişisel
  ekip her yeteneği desteklemediğinden "ücretsiz imza yeter" garantisi verilmez.
- Windows 11'de PWA widget'ı ayrı bir yoldur (manifest `widgets`); istersen onu da ekleyebilirim.
